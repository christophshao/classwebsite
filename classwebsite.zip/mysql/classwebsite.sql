-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2020 年 05 月 22 日 07:11
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `classwebsite`
--

-- --------------------------------------------------------

--
-- 表的结构 `classpeople`
--

CREATE TABLE IF NOT EXISTS `classpeople` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picsrc` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lb` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `classpeople`
--

INSERT INTO `classpeople` (`id`, `name`, `picsrc`, `lb`) VALUES
(1, '小明', 'students.jpg', '学生'),
(4, '王老师', 'teachers.jpg', '教师'),
(3, '小刚', 'students.jpg', '学生'),
(6, 'jack', 'students.jpg', '学生'),
(7, 'Leo', 'students.jpg', '学生'),
(10, '小兰', 'students.jpg', '学生'),
(9, '小绿', 'students.jpg', '学生'),
(11, '唐三', 'students.jpg', '学生'),
(12, '霍雨浩', 'students.jpg', '学生'),
(14, '萧炎', 'students.jpg', '学生'),
(15, '阿铁打', 'teachers.jpg', '教师'),
(17, '卡璐璐', 'teachers.jpg', '教师'),
(18, '赛小息', 'teachers.jpg', '教师'),
(20, '窝边草', 'teachers.jpg', '教师'),
(21, '12', '112.jpg', '学生');

-- --------------------------------------------------------

--
-- 表的结构 `classpic`
--

CREATE TABLE IF NOT EXISTS `classpic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picsrc` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lb` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=24 ;

--
-- 转存表中的数据 `classpic`
--

INSERT INTO `classpic` (`id`, `name`, `picsrc`, `lb`, `dt`) VALUES
(18, '智慧乡村教育', 'timg (1).jpg', 'class', '1589958610'),
(13, '智慧课堂', 'ddsh1.jpg', 'class', '1589958214'),
(14, '科研教育', 'ddsh2.jpg', 'class', '1589958319'),
(15, '智慧教室', 'ddsh3.jpg', 'class', '1589958340'),
(16, '智慧教育大数据', 'u=2850218479,3533861579&fm=26&gp=0.jpg', 'class', '1589958407'),
(17, '头脑风暴', 'timg.jpg', 'class', '1589958531'),
(19, '智慧教育软件', 'timg (2).jpg', 'class', '1589958715'),
(20, '教育你和我', 'timg (3).jpg', 'class', '1589958800'),
(22, '学习智慧上网', 'u=2888100757,3042408569&fm=26&gp=0.jpg', 'class', '1589959005'),
(23, '智慧教育课堂讨论', '112.jpg', 'class', '1589959052');

-- --------------------------------------------------------

--
-- 表的结构 `class_sth`
--

CREATE TABLE IF NOT EXISTS `class_sth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bt` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `writer` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picsrc` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nr` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dt` int(11) NOT NULL,
  `lb` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `class_sth`
--

INSERT INTO `class_sth` (`id`, `bt`, `writer`, `picsrc`, `nr`, `dt`, `lb`) VALUES
(1, '信息的发展', '小明', '1.jpg', '随着小糸车灯信息化进程的发展，仅有的一套ERP系统无法满足日益增长的信息化需求。小糸车灯迫切的需要一套系统能够管理ERP所不能管理的日常工作部分。小糸车灯技术管理中心作为企业的核心部门，肩负着产品研发和管理的重任，研发工作和其它部门的协同需要一套合适的软件来支撑，研发相关文档需要一套合适的软件来管理，研发人员的日常工作需要一套合适的系统来指导。', 1520739133, '班级新闻'),
(2, '击鼓传花真好玩', '小刚', '2.jpg', '通过Velcro系统，建立技术管理中心完善的文档管理体系，专利申请管理体系；梳理并落实研发部的设计变更流程、数据发送流程以及研讨会流程；实现对产品研发项目的管控，对设计人员日常工作的计划追踪。通过Velcro系统，建立技术管理中心完善的文档管理体系，专利申请管理体系；梳理并落实研发部的设计变更流程、数据发送流程以及研讨会流程；实现对产品研发项目的管控，对设计人员日常工作的计划追踪。', 1520739186, '班级活动'),
(3, '备战二级考！！！', '小红', '3.jpg', '上海小糸车灯有限公司是中日合资企业，创建于1989年4月1日。中方股东为上海汽车股份有限公司，日方股东为株式会社小糸制作所和丰田通商株式会社。上海小糸车灯有限公司是中日合资企业，创建于1989年4月1日。中方股东为上海汽车股份有限公司，日方股东为株式会社小糸制作所和丰田通商株式会社。', 1520739232, '班级公告'),
(5, '恭喜XX同学在第三届校园摄影大赛比赛中获奖', '小刚', 'event4.jpg', '恭喜XX同学在第三届校园摄影大赛比赛中获二等奖，没想到XX同学还有这一手~恭喜XX同学在第三届校园摄影大赛比赛中获二等奖，没想到XX同学还有这一手~恭喜XX同学在第三届校园摄影大赛比赛中获二等奖，没想到XX同学还有这一手~恭喜XX同学在第三届校园摄影大赛比赛中获二等奖，没想到XX同学还有这一手~', 1520767201, '班级新闻'),
(6, '本周六组织爬佘山，大家积极报起名来', '小红', '2.jpg', '本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来本周六组织爬佘山，大家积极报起名来', 1520767312, '班级活动'),
(7, '恭喜XXX收到新加坡国立大学研究生offer', '萧炎', 'event2.jpg', '恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer恭喜XXX收到新加坡国立大学研究生offer', 1520767354, '班级新闻'),
(8, '9月20号班级秋游，早上七点校南门口集合', '小绿', 'event3.jpg', '9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合9月20号班级秋游，早上七点校南门口集合', 1520767396, '班级公告'),
(9, '国庆七天大假，放10月1号~7号', '小五颜六色', '3.jpg', '国庆七天大假，放10月1号~7号，小伙伴们请安排好时间，回家的同学车票都买好了？国庆七天大假，放10月1号~7号，小伙伴们请安排好时间，回家的同学车票都买好了？', 1520767451, '班级公告'),
(10, '学校为我们组织成了一个集体', '全体班委', 'teachers.jpg', '团结是我班的法宝，我们凭借着它战胜每一个困难。在运动会上，我班在接力方面取得了好成绩，大家不但配合默契，而且齐心协力。每一棒都很精彩，大家努力拼搏，使出最大的力气，向前冲刺。不仅运动员如此，拉拉队也不闲着，使劲地喊加油，为运动员添加信心。这是团结的一面。团结是我班的法宝，我们凭借着它战胜每一个困难。在运动会上，我班在接力方面取得了好成绩，大家不但配合默契，而且齐心协力。每一棒都很精彩，大家努力拼搏，使出最大的力气，向前冲刺。不仅运动员如此，拉拉队也不闲着，使劲地喊加油，为运动员添加信心。这是团结的一面。', 1520767610, '班级新闻'),
(11, '充满活力的班级', '嘻嘻嘻', '1.jpg', '26个窈窕淑女，22个谦谦君子组成了我们五年级（3）班一个充满活力、积极向上、团结友爱的集体。我们都是活泼、可爱、善良、有爱心的孩子，有着同样的奋斗目标，怀着同样的梦想，共同努力着、奋斗着、进步着。通过我们的努力，我们也取得了骄人的成绩，经常在年级中名列前茅。我们班级,是一个其乐融融的集体,同学们有很多的共同点,譬如说,大家都是健康又热心助人的少先队员,在班上大家都能相处融洽。我们的老师总是设身处地地为我们着想，孜孜不倦地教导我们，不但在学习上，更在思想上，老师好比蜡烛，燃烧了自己，照亮了我们的前程。我们深爱着老师，老师也深爱着我们。', 1520767661, '班级新闻'),
(12, '观《班级博客》有感', '我欲封天', 'ss_bg.jpg', '今天，我打开电脑，在百度一栏里输入“扬中市实验小学”，进入后找到2006级612，再一次进入了我班的班级博客。刚进入班级博客，就有一首熟悉的《致爱丽丝》在我耳边回响。可是此时，我已没有了心思再去听音乐了，我迫不及待地浏览起了我们的班级博客，班级博客上一个个形形色色的任务栏吸引了我的注意，有学生作品，有班级动态，也有学生留言……我首先关注的是“学生作品”一栏，有张书贤的，有王诗童的，也有匡锡灿的，还有吴凡的，看着他们作文里一个个优美的词语，一段段形象的比喻，我只能自叹不如，同时也下定决心，要写好作文，也上传班级博客，告诉他们，我季安也不是吃干饭的。看完“学生作品”，我不经意间留意到博客最下方还有一个“照片栏”，我仔细地看了看，上面都是我们学校组织活动时，我们十二班的辉煌记忆。咦！这上面还有我呢！我不禁骄傲起来，我也上博客了，这下全校师生都能通过班级博客认识我了，这也要感谢布置班级博客的老师和同学们呀，我在这里对你们说一声：“谢谢你们！”班级博客是一个让同学之间沟通更快捷的平台，也是大家展现自己才艺的舞台。同学们，快来关注班级博客吧！我相信，在老师和大家的共同努力下，我们的班级博客会被建设的越来越好！', 1520767740, '班级新闻'),
(13, '啊!我们又换教室啦！', '小学生', 'event3.jpg', '四零一班啦！”同学们欢呼道。\r\n\r\n9月1日，我们成了四年级的小学生。我们的教室不仅变成新的了，还到了四楼。有了新教室，有好处也有坏处。好处是我们又升了一级，而且教室也新了。坏处是我们进教室之前走的楼梯又多了，更累了。\r\n\r\n总之，现在我们成了一、二、三年级小朋友的大哥哥大姐姐啦！', 1520767838, '班级新闻'),
(14, '智慧教育同学讨论会', '窝边草', '112.jpg', '智慧教育要求我们在遇到教育中存在的问题时，要换一个角度多途径解决问题，用多元化的思维来克服来寻求工作中遇到的难题。如何运用智慧教育来解决教育中存在的难题呢？我在从事班主任工了几条经验，供同行们共同探讨。', 1589959232, '班级公告'),
(16, '智 慧 教 育 ——兴趣优化小学英语课堂教学', '南宫文天', 'ddsh2.jpg', '众所周知，兴趣是最好的老师。小学生的年龄特点是好奇心强、模仿性强、生性好动，注意力持续时间相对较短 。语言学习本身是较为单调枯燥的，刚接触英语的小学生，对英语有极大的好奇心，但是从最初的说说唱唱，读读念念，到后来的写写默默，他们对英语的兴趣就会慢慢减少。因此，如何做到激发并保持学生对英语的学习兴趣成为小学英语课堂教学的重点。那么如何在小学英语课堂教学中做到呢？ 【关键字】美 教育 评价 习惯 众所周知，兴趣是最好的老师。而小学生的年龄特点又是好奇心强、模仿性强、生性好动，注意力持续时间相对较短 。语言学习本身是较为单调枯燥的，刚接触英语的小学生，对英语有着极大的好奇心，但是从最初的说说唱唱，读读念念，到后来的写写默默，他们对英语的兴趣就会慢慢减少，最后甚至不爱学习英语了。因此，如何做到激发学生学习英语的乐趣并保持学生对英语的学习兴趣成为小学英语课堂教学的重点。', 1589959383, '班级新闻'),
(17, '“深度学习与智慧教育”', '西门吹雪', 'ddsh3.jpg', '1.深度学习，是指学生在理解学习的基础上，能够批判性地学习新的知识并接受新的思想，并将新的知识和思想融入到已有的认知结构中。\r\n\r\n2.语文教学过程中，强调教师个人对文本解读必须要有深度，但教师解读文本的深度应符合学生的认知能力。\r\n\r\n3.“有深度的语文课”提倡师生对文本进行个性化的深度解读，但教师对文本的深度解读一定要以学生的深度阅读为前提。\r\n\r\n4.深度学习的课堂，是一个容量大的课堂，但不是容量越大，学习就越深刻，它要容得下足够的知识，容得下对知识的拓展，容得下教师对学生学法的指导，容得下对学生学弟过程的点拨引导。同时，有深度的课堂必定是简约的课堂。\r\n', 1589959460, '班级活动'),
(18, '文化资本视域下智慧校园建设的探索与实践', '林学习要学习', 'timg (3).jpg', '1.黄怀荣教授定义智慧校园是一种通过互联互通的网络通信，向师生提供个性化服务，进行教学过程分析、教学评价以及智能决策，实现一种安全便捷、开放、共享的教育教学环境。\r\n\r\n2.《教育信息化2.0行动计划》中明确提出，要依托互联网、物联网，以人工智能、大数据等新兴技术，利用各类智能设备积极开展新技术支持下教育生态的重构和创新模式的研究，推动智慧教育的发展。\r\n\r\n作者：林学习要学习\r\n链接：https://www.jianshu.com/p/48d83356527f\r\n来源：简书\r\n著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。', 1589959530, '班级新闻'),
(19, '我国智慧教育领域研究热点探析', '林学习要学习', 'ddsh3.jpg', '1.祝智庭教授构建了理解智慧教育的基本图式，描述了智慧教育、智慧环境和智慧教学三者之间的关联性，认为智慧教育要以智慧学习环境为技术支撑，以智慧教学法为催化促导，以智慧学习为根本基石。\r\n\r\n2.黄怀荣教授认为智慧教育的本质特征是学习环境的感知性、学习内容的适配性、教育者对学生的尊重和关爱、受教育群体之间的教育公平性、教育系统要素的有机整合及其和谐关系。\r\n\r\n3.陈琳等认为智慧型课程应是着力培养学习者高阶思维能力和适应时代的创新创造能力，使学生更富有智慧地学习，教师更富有智慧地教育教学的课程。\r\n\r\n作者：林学习要学习\r\n链接：https://www.jianshu.com/p/48d83356527f\r\n来源：简书\r\n著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。', 1589959572, '班级活动'),
(20, '智慧学习“内涵、特性与能力要求', '林学习要学习', 'ddsh3.jpg', '1.智慧学习实践活动的特性体现在学习目标高阶化、资源共享开放化、学习交互虚拟化、学习路径个性化、评价多元智能化。日本教育家佐藤学曾说过，深度学习如何实现，建立学习共同体利于实现这个目标。因为，学习共同体中的成员，可以共享学习资源，共同完成学习任务。智慧教育中学生21世纪的生存技能，包括学习和创新技能（主动性和数字素养技能、自我指导和解决问题的能力、沟通和团队协作技能、批判性思维社会和跨文化沟通技巧、高效生产力、责任领导力等）。', 1589959610, '班级活动'),
(21, '智慧课程的内涵、特征及其教与学模式设计研究', '林学习要学习', '112.jpg', '1.学习共同体是指由学习者及其辅助者（包括教师、专家、辅导者等）共同构成的团体，他们彼此之间经常在学习过程中交流、分享各种学习资源，共同完成学习任务，因而在成员之间形成了相互影响、互相促进的人际关系。在中学教学过程中，学生和教师就成为学习共同体的两个主要角色。\r\n\r\n2.基于时间轴的学习共同体任务分工（表格）。\r\n\r\n3.任务驱动课堂学习流程按照三步进行：难点释疑、探究应用、巩固提升。\r\n\r\n作者：林学习要学习\r\n链接：https://www.jianshu.com/p/48d83356527f\r\n来源：简书\r\n著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。', 1589959745, '班级公告');

-- --------------------------------------------------------

--
-- 表的结构 `index_show`
--

CREATE TABLE IF NOT EXISTS `index_show` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nr` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `index_show`
--

INSERT INTO `index_show` (`id`, `bt`, `nr`, `dt`) VALUES
(4, 'Knowledge is power', 'Knowledge is power. You can''t begin a career, for that matter even a relationship, unless you know everything there is to know about it You can''t begin a career, for that matter even a relationship, unless you know everything there is to know about it..', '1520759964');

-- --------------------------------------------------------

--
-- 表的结构 `menu1`
--

CREATE TABLE IF NOT EXISTS `menu1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `menu1`
--

INSERT INTO `menu1` (`id`, `name`, `address`) VALUES
(1, 'Home', '/classwebsite/index.php'),
(2, '智慧教育', '/classwebsite/html/classpic.php'),
(14, '班级新闻', '/classwebsite/html/class_zx.php'),
(7, '班级成员', '/classwebsite/html/classpeople.php');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userflag` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `userflag`) VALUES
(1, 'admin', 'admin', '1'),
(2, '1', '1', '0');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
