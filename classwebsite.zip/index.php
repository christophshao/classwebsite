<?php require_once('admin/connect.php');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>智慧乡村教育</title>
	<link rel="icon" href="img/title.png" type="image">
	
<link href="css/index.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="header">
<?php require_once('html/header.php');?>
   <div class="header_right">
       <div class="wz_show">
          <?php
		  $sql = "select * from index_show order by dt desc limit 1";
		  $res = mysqli_query($db,$sql);
		  while($arr = mysqli_fetch_assoc($res)){
		  ?>
          <div class="bt"><?php echo $arr['bt'];?></div>
          <div class="nr">
          <?php echo $arr['nr'];?>
          </div>
          <?php
		  }
		  ?>
          <div class="welcome">Welcome all the friends</div>
       </div>
   </div>
</div>
    <!-- header结束-->
    <div class="pagebody">
        <div class="class_sth">
             <div class="class_pic"><img src="img/1.jpg" width="100%" height="100%"/></div>
             <div class="class_bt">班级新闻</div>
             <div class="nav">
             <?php
			 $sql = "select * from class_sth where lb = '班级新闻' order by dt desc limit 6";
			 $res = mysqli_query($db,$sql);
			 while($arr = mysqli_fetch_assoc($res)){
			 ?>
             <div class="class_title">
             <a href="/classwebsite/html/class_xx.php?id=<?php echo $arr['id'];?>" class="lj_class_title"><?php echo $arr['bt'];?></a></div>
             <?php
			 }
			 ?>
             </div>
             <div class="more"><a href="html/class_zx.php" class="lj_more" title="查看更多...">查看更多</a></div>
        </div>
        <div class="class_sth">
             <div class="class_pic"><img src="img/2.jpg" width="100%" height="100%"/></div>
             <div class="class_bt">班级活动</div>
             <div class="nav">
             <?php
			 $sql = "select * from class_sth where lb = '班级活动' order by dt desc limit 6";
			 $res = mysqli_query($db,$sql);
			 while($arr = mysqli_fetch_assoc($res)){
			 ?>
             <div class="class_title">
             <a href="/classwebsite/html/class_xx.php?id=<?php echo $arr['id'];?>" class="lj_class_title"><?php echo $arr['bt'];?></a></div>
             <?php
			 }
			 ?>
             </div>
             <div class="more"><a href="html/class_zx.php" class="lj_more" title="查看更多...">查看更多</a></div>
        </div>
        <div class="class_sth">
             <div class="class_pic"><img src="img/3.jpg" width="100%" height="100%"/></div>
             <div class="class_bt">班级公告</div>
             <div class="nav">
             <?php
			 $sql = "select * from class_sth where lb = '班级公告' order by dt desc limit 6";
			 $res = mysqli_query($db,$sql);
			 while($arr = mysqli_fetch_assoc($res)){
			 ?>
             <div class="class_title">
             <a href="/classwebsite/html/class_xx.php?id=<?php echo $arr['id'];?>" class="lj_class_title"><?php echo $arr['bt'];?></a></div>
             <?php
			 }
			 ?>
             </div>
             <div class="more"><a href="html/class_zx.php" class="lj_more" title="查看更多...">查看更多</a></div>
        </div>
		
    </div>
    <!--pagebody结束-->
<?php require_once('html/footer.php');?>
</body>
</html>