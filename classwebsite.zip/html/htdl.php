<?php
require_once('../admin/connect.php');
if(isset($_POST['user'])){
$user = $_POST['user'];
$pwd = $_POST['pwd'];
$sql ="select * from user where username = '$user' and password = '$pwd'";
$res = mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
$arr = mysqli_fetch_assoc($res);
$userflag = $arr['userflag'];
if($userflag == 1&&($num>0)){
	$_SESSION['userflag'] = $userflag;
	$_SESSION['user'] = $user;
	echo '<script>alert("登录成功！");window.location.href="htgl.php";</script>';
}else if($userflag == 0&&($num>0)){
    echo '<script>alert("您无权限访问后台！");window.location.href="/classwebsite/index.php";</script>';
}else{
    echo '<script>alert("登录失败！");window.location.href="htdl.php";</script>';	
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>后台管理</title>
<link href="../css/htdl.css" rel="stylesheet" type="text/css">
</head>
<body background="../img/download.jpg">
   <div class="dl">
       <div class="bt">用户后台登录</div>
       <form method="post" action="htdl.php" >
       <input type="text" class="username" name="user" placeholder="账号：admin"><br><br>
       <input type="password" class="username" name="pwd" placeholder="密码：admin"><br><br>
       <input type="submit" value="登录" class="submit_dl"/>
       </form><br>
       <span><a href="../index.php">返回首页</a></span>
   </div>
</body>
</html>