<?php require_once('../admin/connect.php');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>班级文章信息页面</title>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/class_xx.css" rel="stylesheet" type="text/css">
</head>
<body background="../img/download.jpg">
<div class="header">
<?php require_once('header.php');?>
</div>
<!--header结束-->
<div class="pagebody">
    <div class="left">
      <div class="nav">
          <div class="bt">班级新闻</div>
             <?php
			 $sql = "select * from class_sth where lb = '班级新闻' order by dt desc limit 4";
			 $res = mysqli_query($db,$sql);
			 while($arr = mysqli_fetch_assoc($res)){
			 ?>
             <div class="title"><a href="/classwebsite/html/class_xx.php?id=<?php echo $arr['id'];?>" class="lj_title"><?php echo $arr['bt'];?></a></div>
             <?php
			 }
			 ?>
      </div>
      <div class="nav">
          <div class="bt">班级活动</div>
             <?php
			 $sql = "select * from class_sth where lb = '班级活动' order by dt desc limit 4";
			 $res = mysqli_query($db,$sql);
			 while($arr = mysqli_fetch_assoc($res)){
			 ?>
             <div class="title"><a href="/classwebsite/html/class_xx.php?id=<?php echo $arr['id'];?>" class="lj_title"><?php echo $arr['bt'];?></a></div>
             <?php
			 }
			 ?>
      </div>
      <div class="nav">
          <div class="bt">班级公告</div>
             <?php
			 $sql = "select * from class_sth where lb = '班级公告' order by dt desc limit 4";
			 $res = mysqli_query($db,$sql);
			 while($arr = mysqli_fetch_assoc($res)){
			 ?>
             <div class="title"><a href="/classwebsite/html/class_xx.php?id=<?php echo $arr['id'];?>" class="lj_title"><?php echo $arr['bt'];?></a></div>
             <?php
			 }
			 ?>
      </div>
    </div>
    <!--left-->
    <div class="right">
        <?php
		$id = $_GET['id'];
		$sql = "select * from class_sth where id = $id";
		$res = mysqli_query($db,$sql);
		while($arr = mysqli_fetch_assoc($res)){
		?>
        <div class="wz_bt"><?php echo $arr['bt'];?></div>
        <div class="wz_xx"><?php echo '作者：'.$arr['writer'];?>&nbsp;&nbsp;<?php echo @date('m/d',$arr['dt']);?></div>
        <div class="wz_nr"><?php echo $arr['nr'];?></div>
        <div class="wz_pic"><img src="../img/<?php echo $arr['picsrc'];?>" width="100%" height="100%"/></div>
        <?php
		}
		?>
   </div>
   
</div>
<!--pagebody-->
<?php require_once('footer.php');?>
</body>
</html>