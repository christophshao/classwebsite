<div class="top">
    <div class="logo">
    	<span class="yl">Wisdom&nbsp;</span>Education
    </div>
    <div class="menu">
    <ul>
    <?php
	$sql = "select * from menu1 order by id limit 5";
	$res = mysqli_query($db,$sql);
	while($arr = mysqli_fetch_assoc($res)){
	?>
    <li><a href="<?php echo $arr['address'];?>" class="lj_menu1" title="<?php echo $arr['name'];?>"><?php echo $arr['name'];?></a></li>
    <?php
	}
	?>
    </ul>
    </div>
</div>