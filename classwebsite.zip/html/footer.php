<div class="footer"><br>
<br><br>
&copy;sjf<br><br>
图片来自百度，如有侵权，请立刻告知，马上删除<br><Br>

<a href="/classwebsite/html/htdl.php" class="lj_htgl">后台管理</a>
</div>
<!--footer结束-->