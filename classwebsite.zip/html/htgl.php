<?php 
require_once('../admin/connect.php');
if(!isset($_SESSION['userflag'])||$_SESSION['userflag'] == '0'){
	echo '<script>alert("无权限访问后台，即将返回首页~");window.location.href="/classwebsite/index.php";</script>';
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>后台管理</title>
<link href="../css/htdl.css" rel="stylesheet" type="text/css">
</head>
<body background="../img/download.jpg">
<div class="pagebody">
    <div class="left">
        <div class="top">欢迎<?php echo $_SESSION['user'];?>,登录<a href="../admin/stop.php" class="lj_stop">【注销】</a></div><br>
        
        <div class="menu"><a href="../admin/show_tj.php" class="lj_menu" target="right">首页展示区添加</a></div>
        <div class="menu"><a href="../admin/show_gl.php" class="lj_menu" target="right">首页展示区管理</a></div><hr/>
        
        <div class="menu"><a href="../admin/menu1_tj.php" class="lj_menu" target="right">导航栏添加</a></div>
        <div class="menu"><a href="../admin/menu1_gl.php" class="lj_menu" target="right">导航栏管理</a></div><hr/>
                
        <div class="menu"><a href="../admin/classpic_tj.php" class="lj_menu" target="right">智慧教育上传</a></div>
        <div class="menu"><a href="../admin/classpic_gl.php" class="lj_menu" target="right">智慧教育管理</a></div><hr/>
        
        <div class="menu"><a href="../admin/classpeople_tj.php" class="lj_menu" target="right">班级成员上传</a></div>
        <div class="menu"><a href="../admin/classpeople_gl.php" class="lj_menu" target="right">班级成员管理</a></div><hr/>
        
        <div class="menu"><a href="../admin/class_sth_tj.php" class="lj_menu" target="right">班级新闻/活动/通知上传</a></div>
        <div class="menu"><a href="../admin/class_sth_gl.php" class="lj_menu" target="right">班级新闻/活动/通知管理</a></div><hr/>
    </div>


   <div class="right">
      <iframe name="right" src="../admin/menu1_gl.php" width="100%" height="100%" frameborder="0"></iframe>
   </div>
</div>
</body>
</html>