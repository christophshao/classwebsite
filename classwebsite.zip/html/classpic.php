<?php require_once('../admin/connect.php');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>点滴生活</title>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/classpic.css" rel="stylesheet" type="text/css">
</head>
<body background="../img/download.jpg">
<div class="header">
    <?php require_once('header.php');?>
    <div class="tb">智慧教育</div>
    <div class="ss">
        <form method="post" action="classpic.php">
        	<input type="text" name="ss" placeholder="请输入图片名称" class="text_ss"/><input type="submit" value="搜索" class="submit_ss">
        </form>
    </div>
</div>
<!--header结束-->
<div class="pagebody">
    <div class="tu">
		<?php
        @$ss = $_POST['ss'];
        $length=8;
        @$pagenow = $_GET['page']>0?$_GET['page']:1;
        $offset = ($pagenow - 1)*$length;
        $sqltot = "select count(*) from classpic";
        $restot= mysqli_query($db,$sqltot);
        $arrtot = mysqli_fetch_row($restot);
        $pagetot = ceil($arrtot['0']/$length);
        $sql = "select * from classpic where name like '%{$ss}%' order by dt desc limit $offset,$length";
        $res = mysqli_query($db,$sql);
		$num = mysqli_affected_rows($db);
        while($arr = mysqli_fetch_assoc($res)){
        ?>
			<div class="tw">
				<div class="pic"><img src="../img/<?php echo $arr['picsrc'];?>" width="100%" height="100%"/></div>
				<div class="name"><?php echo $arr['name'];?></div>
			</div>
        <?php
        }
        ?>
    </div>
    <div class="page">
      <?php
	  $i = 1;
	  while($i<=$pagetot){
		  echo '<a href="classpic.php?page='.$i.'" class="lj_page2">'.$i.'</a>'.'&nbsp;&nbsp;';
		  $i++;
		  }
	  ?>
    </div>
</div>
<!--pagebody结束-->
<?php require_once('footer.php');?>
</body>
</html>