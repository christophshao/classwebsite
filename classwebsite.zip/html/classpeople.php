<?php require_once('../admin/connect.php');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>班级成员</title>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<link href="../css/classpeople.css" rel="stylesheet" type="text/css">
</head>
<body background="../img/download.jpg">
<div class="header">
<?php require_once('header.php');?>
</div>
<!--header结束-->
<div class="pagebody">
    <div class="title">学生列表</div>
    <div class="people">
        <?php
		$length = 8;
		@$pagenow = $_GET['page']>0?$_GET['page']:1;
		$sqltot = "select count(*) from classpeople where lb = '学生'";
		$restot = mysqli_query($db,$sqltot);
		$arrtot = mysqli_fetch_row($restot);
		$pagetot = ceil($arrtot['0']/$length);
		$offset = ($pagenow - 1) * $length;
		$sql = "select * from classpeople where lb = '学生' order by id limit $offset,$length";
		$res = mysqli_query($db,$sql);
		while($arr = mysqli_fetch_assoc($res)){
		?>
        <div class="tw" style="background:url(../img/<?php echo $arr['picsrc'];?>); background-size:100% 100%;">
            <div class="wen"><?php echo $arr['lb'].'：'.$arr['name'];?></div>
        </div>
        <?php
		}
		?>
    </div>
    <div class="page">
    <?php
	$i = 1;
	while($i<=$pagetot){
		echo '<a href="classpeople.php?page='.$i.'" class="lj_page2">'.$i.'</a>'.'&nbsp;&nbsp;';
		$i++;
		}
	?>
    </div>
    <div class="title">教师列表</div>
    <div class="people">
        <?php
		$length = 8;
		@$pagenow = $_GET['page']>0?$_GET['page']:1;
		$sqltot = "select count(*) from classpeople where lb = '教师'";
		$restot = mysqli_query($db,$sqltot);
		$arrtot = mysqli_fetch_row($restot);
		$pagetot = ceil($arrtot['0']/$length);
		$offset = ($pagenow - 1) * $length;
		$sql = "select * from classpeople where lb = '教师' order by id limit $offset,$length";
		$res = mysqli_query($db,$sql);
		while($arr = mysqli_fetch_assoc($res)){
		?>
        <div class="tw" style="background:url(../img/<?php echo $arr['picsrc'];?>); background-size:100% 100%;">
            <div class="wen"><?php echo $arr['lb'].'：'.$arr['name'];?></div>
        </div>
        <?php
		}
		?>
    </div>
    <div class="page">
    <?php
	$i = 1;
	while($i<=$pagetot){
		echo '<a href="classpeople.php?page='.$i.'" class="lj_page2">'.$i.'</a>'.'&nbsp;&nbsp;';
		$i++;
		}
	?>
    </div>
</div>
<!--pagebody-->
<?php require_once('footer.php');?>
</body>
</html>