<?php
require_once('connect.php');
if(isset($_POST['name'])){
$name = $_POST['name'];
$picsrc = $_FILES['file']['name'];
$file = $_FILES['file']['tmp_name'];
$lb = $_POST['lb'];
$sql = "insert into classpeople(name,picsrc,lb)values('$name','$picsrc','$lb')";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if(move_uploaded_file($file,'../img/'.$picsrc)&&($num>0)){
	echo '<script>alert("上传成功！");window.locaiotn.href="classpeople_tj.php";</script>';
}else{
	echo '上传失败！';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body style="text-align:center;">
<br />
<br />
<br />
<br />
    <form method="post" action="classpeople_tj.php" enctype="multipart/form-data">
    名称：<input name="name" type="text"><br><br>
    图片：
    <input type="file" name="file"><br><br>
    类别：
    <select name="lb">
       <option value="学生">学生</option>
       <option value="教师">教师</option>
    </select><br><br>
    <input type="submit" value="上传"/>
    </form>
</body>