<?php
require_once('connect.php');
$id = $_GET['id'];
$sql = "delete from classpic where id = $id";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if($num>0){
	echo '<script>alert("删除成功！");window.location.href="classpic_gl.php";</script>';
}else{
	echo '删除失败！';
	}
?>