<?php
session_start();
header("content-type:text/html;charset=utf-8");
date_default_timezone_set("PRC");
$db = mysqli_connect('127.0.0.1','root','root','classwebsite');
if(!$db){echo '数据库连接错误';}
mysqli_query($db,'set names utf8');
?>
