<?php
require_once('connect.php');
$id = $_GET['id'];
$sql = "delete from class_sth where id = $id";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if($num>0){
	echo '<script>alert("删除成功！");window.location.href="class_sth_gl.php";</script>';
}else{
	echo '删除失败！';
	}
?>