<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<?php
require_once('connect.php');
$id = $_GET['id'];
if(isset($_POST['name'])){
$namenew = $_POST['name'];
$addressnew = $_POST['address'];
$sql = "update menu1 set name='$namenew',address='$addressnew' where id = $id";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if($num>0){
	echo '<script>alert("修改成功！");window.location.href="menu1_gl.php";</script>';
}else{
	echo '修改失败！';
	}
}else{
	$sql = "select * from menu1 where id = $id";
	$res = mysqli_query($db,$sql);
	$arr = mysqli_fetch_assoc($res);
	$name = $arr['name'];
	$address = $arr['address'];
	}
?>
<form method="post" action="menu1_xg.php?id=<?php echo $id;?>">
名称：<input type="text" name="name" value="<?php echo $name;?>"/><br /><br />
地址：<input type="text" name="address" value="<?php echo $address;?>"/><br /><br />
<input type="submit" value="修改"/><br /><br />
</form>
</body>
</html>