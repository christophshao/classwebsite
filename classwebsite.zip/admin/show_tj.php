<?php
require_once('connect.php');
if(isset($_POST['bt'])){
$bt = $_POST['bt'];
$nr = $_POST['nr'];
$dt = time();
$sql = "insert into index_show(bt,nr,dt)values('$bt','$nr',$dt)";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if($num>0){
	echo '<script>alert("上传成功！");window.locaiotn.href="show_tj.php";</script>';
}else{
	echo '上传失败！';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body style="text-align:center;">
<br />
<br />
<form method="post" action="show_tj.php">
标题：<input name="bt" type="text"/><br><br>
内容：<br>
<textarea name="nr" cols="50" rows="5"></textarea><br>
<input type="submit" value="添加"/>
</form>
</body>