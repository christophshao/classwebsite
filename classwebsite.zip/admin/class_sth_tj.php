<?php
require_once('connect.php');
if(isset($_POST['bt'])){
$bt = $_POST['bt'];
$writer = $_POST['writer'];
$picsrc = $_FILES['file']['name'];
$file = $_FILES['file']['tmp_name'];
$nr = $_POST['nr'];
$dt = time();
$lb = $_POST['lb'];
$sql = "insert into class_sth(bt,writer,picsrc,nr,dt,lb)values('$bt','$writer','$picsrc','$nr',$dt,'$lb')";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if(move_uploaded_file($file,'../img/'.$picsrc)&&($num>0)){
	echo '<script>alert("上传成功！");window.locaiotn.href="classpeople_tj.php";</script>';
}else{
	echo '上传失败！';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body style="text-align:center;">
<br />
<br />
<br />
<br />
    <form method="post" action="class_sth_tj.php" enctype="multipart/form-data">
    标题：<input name="bt" type="text"><br><br>
    作者：<input name="writer" type="text"><br><br>
    图片：
    <input type="file" name="file"><br><br>
    内容：<br>
    <textarea name="nr" rows="5" cols="50"></textarea><br>
    类别：
    <select name="lb">
       <option value="班级新闻">班级新闻</option>
       <option value="班级活动">班级活动</option>
       <option value="班级公告">班级公告</option>  
    </select><br><br>
    <input type="submit" value="上传"/>
    </form>
</body>