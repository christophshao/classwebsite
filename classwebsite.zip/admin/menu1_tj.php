<?php
require_once('connect.php');
if(isset($_POST['name'])){
$name = $_POST['name'];
$address = $_POST['address'];
$sql = "insert into menu1(name,address)values('$name','$address')";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if($num>0){
	echo '<script>alert("上传成功！");window.locaiotn.href="menu1_tj.php";</script>';
}else{
	echo '上传失败！';
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body style="text-align:center;">
<br />
<br />
<br />
<br />
    <form method="post" action="menu1_tj.php">
    名称：<input name="name" type="text"><br><br>
    地址：<input name="address" type="text"><br><br>
    <input type="submit" value="上传"/>
    </form>
</body>
