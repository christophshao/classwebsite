<?php
require_once('connect.php');
unset($_SESSION['user']);
unset($_SESSION['userflag']);
if(!isset($_SESSION['user'])){
	echo '<script>alert("退出成功！");window.location.href="/classwebsite/index.php";</script>';
	}
?>