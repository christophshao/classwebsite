<?php require_once('connect.php');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="/classwebsite/css/gl.css" rel="stylesheet" type="text/css">
</head>
<body><br>
<br>
<table border="1px" align="center" width="80%">
    <tr>
        <th>ID</th>
        <th>标题</th>
        <th>内容</th>
        <th>上传时间</th>
        <th>操作</th>
    </tr>
    <?php
	$sql = "select * from index_show order by dt desc";
	$res = mysqli_query($db,$sql);
	while($arr = mysqli_fetch_assoc($res)){
	?>
    <tr align="center">
       <td><?php echo $arr['id'];?></td>
       <td><?php echo $arr['bt'];?></td>
       <td><?php echo $arr['nr'];?></td>
       <td><?php echo date('Y-m-d',$arr['dt']) ;?></td>
       <td><a href="show_sc.php?id=<?php echo $arr['id'];?>" class="lj_cz">删除</a></td>
    </tr>
    <?php
	}
	?>
</table>
</body>
</html>