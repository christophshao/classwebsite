<?php
require_once('connect.php');
if(isset($_POST['name'])){
$name = $_POST['name'];
$picsrc = $_FILES['file']['name'];
$file = $_FILES['file']['tmp_name'];
$lb = $_POST['lb'];
$dt = time();
$sql = "insert into classpic(name,picsrc,lb,dt)values('$name','$picsrc','$lb',$dt)";
mysqli_query($db,$sql);
$num = mysqli_affected_rows($db);
if(move_uploaded_file($file,'../img/'.$picsrc)&&($num>0)){
	echo '<script>alert("上传成功！");window.locaiotn.href="classpic_tj.php";</script>';
}else{
	echo '上传失败！';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body style="text-align:center;">
<br />
<br />
<br />
<br />
    <form method="post" action="classpic_tj.php" enctype="multipart/form-data">
    名称：<input name="name" type="text"><br><br>
    图片：
    <input type="file" name="file"><br><br>
    类别：
    <select name="lb">
       <option value="class">班级</option>
       <option value="others">其他</option>
    </select><br><br>
    <input type="submit" value="上传"/>
    </form>
</body>
</html>