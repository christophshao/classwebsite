<?php require_once('connect.php');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link href="/classwebsite/css/gl.css" rel="stylesheet" type="text/css">
</head>
<body><br>
<br>
<table border="1px" align="center" width="80%">
    <tr>
        <th>ID</th>
        <th>名称</th>
        <th>图片</th>
        <th>所属类别</th>
        <th>操作</th>
    </tr>
    <?php
	$sql = "select * from classpeople order by id desc";
	$res = mysqli_query($db,$sql);
	while($arr = mysqli_fetch_assoc($res)){
	?>
    <tr align="center">
       <td><?php echo $arr['id'];?></td>
       <td><?php echo $arr['name'];?></td>
       <td><img src="/classwebsite/img/<?php echo $arr['picsrc'];?>" width="100px" height="100px"/></td>
       <td><?php echo $arr['lb'];?></td>
       <td><a href="classpeople_sc.php?id=<?php echo $arr['id'];?>" class="lj_cz">删除</a></td>
    </tr>
    <?php
	}
	?>
</table>
</body>
</html>